#define macro_baseline_cycle_count  baseline_cycle_count = 596;
#define macro_baseline_cpu_time baseline_cpu_time = 228864;
#define macro_improved_cycle_count improved_cycle_count = 92;
#define macro_improved_cpu_time improved_cpu_time = 35328;
